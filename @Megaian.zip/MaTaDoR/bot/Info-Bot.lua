bot_token = "618431647:AAGrrLCcwcYDV9L1LrkU2N_l2aliVxVwFO8" -- توکن رباتُ
channel_username = '@Megaian' -- آیدی کانال
channel_inline = 'Bodyguard_Team' -- آیدی کانال بدون @
sudo_username = '@Megian_Boy' -- آیدی سازنده ربات
gp_sudo = -1001349230237 -- آیدی گروه سودو ها
SUDO = 611641766 -- آیدی سودو اصلی
BotMaTaDoR_id = 514421515 --آیدی ربات cli
BotMaTaDoR_idapi = 618431647 --آیدی ربات api
RedisIndex = '1' -- شماره ردیس
EndPm = " ツ"

--[[
opened By @Megaian_Boy AND @Samyar65
My Channel @Megaian & @Bodyguard_Team
]]--